//include the necessary header files
#include <iostream>
#include <string>
#include "character.h"

using namespace std;

//constructors
	Character::Character(string name_, string race_, int level, int health)
    {
        name = name_;
        race = race_;
        this->level = level;
        this->health = health;
    }
    Character::Character()
    {
    }

	//getter functions
	string Character::getName() const
    {
        return name;
    }
	string Character::getRace() const
    {
        return race;
    }
	int Character::getLevel() const
    {
        return level;
    }
	int Character::getHealth() const
    {
        return health;
    }

	//setter functions
	void Character::SetName(string newName)
    {
        name = newName;
    }
	void Character::SetRace(string newRace)
    {
        race = newRace;
    }
	void Character::SetLevel(int newLevel)
    {
        level = newLevel;
    }
	void Character::SetHealth(int newHealth)
    {
        health = newHealth;
    }
	
    void Character::Print()
    {
        cout<<"Character Status: "<<endl;
        cout<<"Name: "<<getName()<<endl;
        cout<<"Race: "<<getRace()<<endl;
        cout<<"Level: "<<getLevel()<<endl;
        cout<<"Health "<<getHealth()<<endl;
    }