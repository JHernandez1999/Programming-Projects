//include the necessary header files
#include <iostream>
#include <string>
using namespace std;
#include "wizard.h"

Wizard::Wizard(string wizardName, string wizardRace, int wizardLevel, int wizardHealth, int wizardMana) : Character( wizardName, wizardRace, wizardLevel, wizardHealth)
{
    mana = wizardMana;
}
int Wizard::getMana()
{
    return mana;
}
void Wizard::SetMana(int newMana)
{
    mana = newMana;
}
int Wizard::AddSpell(string spell_name, int spell_damage, int spells_mana)
{
    if( (numOfSpells>=0) && (numOfSpells<10) ) //numOfSpells can be 0-9 (10 spells) 
    {
        spells[numOfSpells].name = spell_name;
        spells[numOfSpells].damage = spell_damage;
        spells[numOfSpells].mana_cost = spells_mana; //changed mana_cost in parameter to spells_mana
        numOfSpells++;
    }

    if( numOfSpells == 9 )
    {
        cout<<"Spell limits reached!"<<endl;
    }
	return numOfSpells;
}
//overloads attack
void Wizard::Attack(Character* charToAttack)
{
    if(spells[0].name == "")
    {
        cout<<"This wizard has no spells!"<<endl;
    }

    if(spells[0].mana_cost > mana)
    {
        cout<<"Insufficient mana points!"<<endl;
    }
    else
    {
        cout<<this->getName()<<" attacked "<<charToAttack->getName()<<" with spell: "<<spells[0].name<<", dealing "<<spells[0].damage<<" damage."<<endl;
        charToAttack->SetHealth( (charToAttack->getHealth() - this->spells[0].damage) );
        this->mana = this->mana - this->spells[0].mana_cost;
    }
    
}
//second attack function
void Wizard::Attack(Character* charToHarm, int spellnum)
{
    if(this->spells[0].name == "")
    {
        cout<<"This Wizard has no spells!"<<endl;
    }
    else
    {
        if( (spellnum<0) || (spellnum>=numOfSpells) )
        {
            cout<<"Invalid spell number!"<<endl;
        }
    }
    
    if(this->mana < this->spells[spellnum].mana_cost)
    {
        cout<<"Insufficient mana points!"<<endl;
    }
    if(this->mana >= this->spells[spellnum].mana_cost)
    {
        cout<<this->getName()<<" attacked "<<charToHarm->getName()<<" with spell: "<<spells[spellnum].name<<", dealing "<<spells[spellnum].damage<<" damage."<<endl;
        charToHarm->SetHealth( (charToHarm->getHealth() - this->spells[spellnum].damage) );
        this->mana = this->mana - this->spells[spellnum].mana_cost;
    }
    
}
//overloads print
void Wizard::Print()
{
    cout<<"Character Status: "<<endl;
    cout<<"Name: "<<this->getName()<<endl;
    cout<<"Race: "<<this->getRace()<<endl;
    cout<<"Level: "<<this->getLevel()<<endl;
    cout<<"Health: "<<this->getHealth()<<endl;
    cout<<"Spells: "<<endl;
    for(int i=0; i<numOfSpells; i++)
    {
        cout<<this->spells[i].name<<endl;
    }
    cout<<"---"<<endl;
}

