#ifndef CHARACTER_H
#define CHARACTER_H

#include <iostream>
#include <string>
using namespace std;

class Character {
	private:
		string name = "";
		string race = "";
		int level = 0;
		int health = 0;

	public:
		//constructors
		Character(string name_, string race_, int level, int health);
		Character();
		//getter functions
		string getName() const;
		string getRace() const;
		int getLevel() const;
		int getHealth() const;

		//setter functions
		void SetName(string newName);
		void SetRace(string newRace);
		void SetLevel(int newLevel);
		void SetHealth(int newHealth);
	
		//other functions
		virtual void Print();
		virtual void Attack(Character * target) =0;
};

#endif