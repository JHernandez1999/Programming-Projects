#include <iostream>
#include <fstream>
#include <string>

#include "character.h"
#include "warrior.h"
#include "wizard.h"
#include "game.h"

using namespace std;


int main()
{
	string filename; 
	cin >> filename;
	ifstream input(filename);

	Game game;
	if (!input.is_open()) {
		cout << "file not found!" << endl;
		exit(0);
	}
	
	//TODO: read the file, make characters and call game.AddCharacter. Do not modify other portions of main
	string tempName;
	string tempRace;
	int tempLevel;
	int tempHealth;

	int tempStamina;
	string tempWName;
	int tempWDamage;
	int tempWStamina;

	int tempMana;
	int tempNumSpells;
	string tempSpellName;
	int tempSpellDamage;
	int tempSpellMana;
	string cType;
	string wctype;


	input>>cType>>tempName>>tempRace>>tempLevel>>tempHealth>>tempStamina>>tempWName>>tempWDamage>>tempWStamina;
	//cout<<cType<<endl<<tempName<<endl<<tempRace<<endl<<tempLevel<<endl<<tempHealth<<endl<<tempStamina<<endl<<tempWName<<endl<<tempWDamage<<endl<<tempWStamina<<endl;

	Warrior* playerWarrior = new Warrior(tempName, tempRace, tempLevel, tempHealth, tempStamina);
	playerWarrior->EquipWeapon(tempWName, tempWDamage, tempWStamina);
	game.AddCharacter(playerWarrior);

	input>>cType>>tempName>>tempRace>>tempLevel>>tempHealth>>tempMana>>tempNumSpells;
	//cout<<cType<<endl<<tempName<<endl<<tempRace<<endl<<tempLevel<<endl<<tempHealth<<endl<<tempMana<<endl<<tempNumSpells<<endl;
	Wizard* playerWizard = new Wizard(tempName, tempRace, tempLevel, tempHealth, tempMana);
	for(int i=0; i<tempNumSpells; i++)
	{
		input.ignore();
		getline(input, tempSpellName);
		input>>tempSpellDamage>>tempSpellMana;
		//cout<<tempSpellName<<endl<<tempSpellDamage<<endl<<tempSpellMana<<endl;
		playerWizard->AddSpell(tempSpellName, tempSpellDamage, tempSpellMana);
	}
	game.AddCharacter(playerWizard);


/*	while(getline(input, charType))
	{
		//if(charType == "")
		//{
		//	break;
		//}

		getline(input,tempName);
		getline(input,tempRace);
		input>>tempLevel>>tempHealth;
		input.ignore();
		cout<<charType<<endl<<tempName<<endl<<tempRace<<endl<<tempHealth<<endl; //testing
		if(charType == "Warrior")
		{
			input>>tempStamina;
			input.ignore();
			getline(input,tempWName);
			input>>tempWDamage>>tempWStamina;
			input.ignore();
			cout<<tempStamina<<endl<<tempWName<<endl<<tempWDamage<<endl<<tempWStamina<<endl;
			Warrior* playerWarrior = new Warrior(tempName, tempRace, tempLevel, tempHealth, tempStamina);
			playerWarrior->EquipWeapon(tempWName, tempWDamage, tempWStamina);
			game.AddCharacter(playerWarrior);
		}
		else if(charType == "Wizard")
		{
			input>>tempMana>>tempNumSpells;
			input.ignore();
			Wizard* playerWizard = new Wizard(tempName, tempRace, tempLevel, tempHealth, tempMana);
			for(int i=0; i<tempNumSpells; i++)
			{
				getline(input,tempSpellName);
				input>>tempSpellDamage>>tempSpellMana;
				input.ignore();
				playerWizard->AddSpell(tempSpellName, tempSpellDamage, tempSpellMana);
			}
			game.AddCharacter(playerWizard);
		}

		input.ignore();
		}
*/
		int option = -1;
	do {
		cout << "Please choose an option: " << endl
			<< "1 - Next Turn" << endl
			<< "2 - Print All Characters" << endl
			<< "3 - Exit" << endl;

		cin >> option;
		cout << endl;

		switch (option) {
			case 1: game.NextTurn(); break;
			case 2: game.Print(); break;
			case 3: exit(0);
			default:
				cout << "Invalid Option!" << endl;
		}
		cout << endl;
	}while (option != 3);

	
	return 0;
}


