#include <iostream>
#include "game.h"
#include <string>
#include "character.h"
#include "warrior.h"
#include "wizard.h"

using namespace std;

Game::Game()
{

}


void Game::RemoveCharacter(int index)
{
    if( (index<0) || (index>1) )
    {
        cout<<"Invalid index!"<<endl;
    }
    else if(players[index] != nullptr)
    {
        players[index] = nullptr;
        num_of_characters--;
    }
    else
    {
        //do nothing
    }
    
}

void Game::AddCharacter(Character* charToAdd)
{
    if(num_of_characters>=2)
    {
        cout<<"Character limit reached, please wait for the next game!"<<endl;
    }
    else
    {
        players[num_of_characters] = charToAdd;
        num_of_characters++;
    }    
}

void Game::NextTurn()
{
    if(num_of_characters<2)
    {
        cout<<"Need more players!"<<endl;
    }

    if(num_of_characters==2)
    {
        players[0]->Attack(players[1]);
        if(players[1]->getHealth() < 0)
        {
            cout<<players[0]->getName()<<" wins!"<<endl;
        }
        else
        {
            players[1]->Attack(players[0]);
            if(players[0]->getHealth() <0)
            {
                cout<<players[1]->getName()<<" wins!"<<endl;
            }
        }                
    }
    current_turn++;
}

void Game::Print()
{
    if(players[0]->getName() != "")
    {
        if(players[0] != nullptr)
        {
            players[0]->Print();
        }
    }

    if(players[1]->getName() != "")
    {
        if(players[1] != nullptr)
        {
            players[1]->Print();
        }
    }
    
}
