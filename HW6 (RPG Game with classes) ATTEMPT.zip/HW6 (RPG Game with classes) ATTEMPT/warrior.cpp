//include the necessary header files
#include <iostream>
#include <string>
using namespace std;
#include "warrior.h"
#include "character.h"

Warrior::Warrior(string warriorName, string warriorRace, int warriorLevel, int warriorHealth, int warriorStamina) : Character(warriorName, warriorRace, warriorLevel, warriorHealth)
{   
   stamina = warriorStamina;
}
int Warrior::getStamina()
{
    return stamina;
}
void Warrior::SetStamina(int staminaToSet)
{
    stamina = staminaToSet;
}
void Warrior::EquipWeapon(string wName, int wDamage, int staminacost)
{
    weapon newWeapon;
    newWeapon.name = wName;
    newWeapon.damage = wDamage;
    newWeapon.stamina_cost = staminacost;
    this->active_weapon = newWeapon;
}
//overload attack function
void Warrior::Attack(Character* characterToAttack)
{
    if(this->active_weapon.name != "")
    {

        if(this->stamina >= this->active_weapon.stamina_cost)
        {
          cout<<this->getName()<<" attacked "<<characterToAttack->getName()<<" with a "<<active_weapon.name<<", dealing "<<active_weapon.damage<<" damage."<<endl;
          this->stamina = (this->stamina - this->active_weapon.stamina_cost);
          characterToAttack->SetHealth(characterToAttack->getHealth() - this->active_weapon.damage);
        }

        if(this->stamina < this->active_weapon.stamina_cost)
        {
        cout<<"Insufficient stamina points!"<<endl;
        } 
    }
    else
    {
        cout<<"Warrior has no weapon!"<<endl;
    }
}
    
//overload print function
void Warrior::Print()
{
    cout<<"Character Status: "<<endl;
    cout<<"Name: "<<this->getName()<<endl;
    cout<<"Race: "<<this->getRace()<<endl;
    cout<<"Level: "<<this->getLevel()<<endl;
    cout<<"Health: "<<this->getHealth()<<endl;
    cout<<"Weapon: "<<this->active_weapon.name<<endl;
    cout<<"---"<<endl;
}
