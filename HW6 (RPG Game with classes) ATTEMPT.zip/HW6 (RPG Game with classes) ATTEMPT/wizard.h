#ifndef WIZARD_H
#define WIZARD_H

#include <iostream>
#include <string>
#include "character.h"
using namespace std;

struct spell {
	string name = "";
	int damage = 0;
	int mana_cost = 0;
};

//Declare class Wizard
class Wizard : public Character
{
	private:
		int mana;
		spell spells[10];
		int numOfSpells = 0;
	public:
		Wizard(string wizardName, string wizardRace, int wizardLevel, int wizardHealth, int wizardMana);
		int getMana();
		void SetMana(int newMana);
		int AddSpell(string spellName, int spellDamage, int spellsMana);
		//overloads attack
		void Attack(Character* characterToHurt);
		//second attack function
		void Attack(Character* characterToHarm, int spellnum);
		//overloads print
		void Print();
};

#endif