#ifndef WARRIOR_H
#define WARRIOR_H

#include <iostream>
#include <string>
#include "character.h"
using namespace std;

struct weapon {
	string name = "";
	int damage = 0;
	int stamina_cost = 0;
};

//Declare Warrior class
class Warrior: public Character
{
	private:
		int stamina = 0;
		weapon active_weapon;
	
	public:
		Warrior(string warriorName, string warriorRace, int warriorLevel, int warriorHealth, int warriorStamina);
		int getStamina();
		void SetStamina(int staminaToSet);
		void EquipWeapon(string weaponName, int weaponDamage, int weaponStaminaCost);
		//overload attack function
		void Attack(Character* characterToAttack);
		//overload print function
		void Print();
};

#endif