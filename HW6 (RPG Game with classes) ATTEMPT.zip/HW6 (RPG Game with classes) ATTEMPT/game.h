#pragma once
#ifndef GAME_H
#define GAME_H

#include <iostream>
#include <string>
#include "character.h"
#include "wizard.h"
#include "warrior.h"

using namespace std;

class Game {
private:
	Character* players[2];
	int current_turn = 0;
	int num_of_characters = 0;
public:
	Game();
	void RemoveCharacter(int index);
	void AddCharacter(Character* c);
	void NextTurn();
	void Print();
	int getCharacters() { return num_of_characters; };
	int getTurn() { return current_turn; };
};

#endif