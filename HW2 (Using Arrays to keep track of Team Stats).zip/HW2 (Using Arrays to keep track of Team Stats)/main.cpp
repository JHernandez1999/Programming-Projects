#include<iostream>
#include<string>
using namespace std;

int main()
{
	int playerJerseyNumber[10];
	int playerRating[10];
	
	int newPlayerJerseyNumber[10];
	int newPlayerRating[10];
	
	
	int i;
	int counter = 1;
	int jerseyNumber;
	int rating;
	
	for(i=0;i<4;i++)
	{
		cout<<"Enter player "<<counter<<"'s jersey number:"<<endl;
		cin>>jerseyNumber;
		
		cout<<"Enter player "<<counter<<"'s rating:"<<endl;
		cin>>rating;
		cout<<endl;
		
		playerJerseyNumber[i] = jerseyNumber;
		playerRating[i] = rating;
		counter++;
	}
	
	cout<<"Enter player "<<counter<<"'s jersey number:"<<endl;
	cin>>jerseyNumber;
		
	cout<<"Enter player "<<counter<<"'s rating:"<<endl;
	cin>>rating;
	
	playerJerseyNumber[4] = jerseyNumber;
	playerRating[4] = rating;
	
	for(i=5; i<10;i++)
	{
		playerJerseyNumber[i] = 0;
		playerRating[i] = 0;
	}
	
	counter = 1;
	cout<<endl;
	cout<<"ROSTER"<<endl;
	
	for(i=0;i<5;i++)
	{
		cout<<"Player "<<counter<<" -- Jersey number: "<<playerJerseyNumber[i]<<", Rating: "<<playerRating[i]<<endl;
		counter++;
	}
	cout<<endl;
	
	char menuChoice = 'l';
	
	while(menuChoice != 'q')
	{
		
		cout<<"MENU"<<endl<<"a - Add player"<<endl<<"d - Remove player"<<endl<<"u - Update player rating"<<endl<<"r - Output players above a rating"<<endl<<"o - Output roster"<<endl<<"q - Quit"<<endl<<endl<<"Choose an option:"<<endl;
		cin>>menuChoice;
				
		
		if(menuChoice == 'a')
		{
			int howManyFull = 0;
			int playerSpot;
			for(int j =0; j<10; j++)
			{
				if(playerRating[j] != 0)
				{
					howManyFull++;
				}
				
			}
			if(howManyFull>=10)
			{
				cout<<"Impossible to add new player: roster is full."<<endl;
				cout<<endl;
			}
			else
			{
				cout<<"Enter a new player's jersey number:"<<endl;
				cin>>jerseyNumber;
				cout<<"Enter the player's rating:"<<endl;
				cin>>rating;
				cout<<endl;
				for(int j=0; j<10; j++)
				{
					if(playerRating[j] == 0)
					{
						playerSpot = j;
					}
				}
				playerJerseyNumber[playerSpot] = jerseyNumber;
				playerRating[playerSpot] = rating;
			}
		}
			
		if(menuChoice == 'd')
		{
			int howManyFull = 0;
			int check;
			int playerSpot;
			for(int j =0; j<10; j++)
			{
				if(playerRating[j] != 0)
				{
					howManyFull++;
				}
				
			}
			if(howManyFull == 0)
			{
				cout<<"Can not delete from empty roster."<<endl;
				cout<<endl;	
			}
			else
			{
				cout<<"Enter a jersey number:"<<endl;
				cin>>jerseyNumber;
				for(int j=0; j<10; j++)
				{
					if(playerJerseyNumber[j] == jerseyNumber)
					{
						check = 1;
						playerSpot = j;
					}
				}
				if(check == 1)
				{
					playerJerseyNumber[playerSpot] = 0;
					playerRating[playerSpot] = 0;
					cout<<endl;
				}
				else
				{
					cout<<"Error! Player "<<jerseyNumber<<" not found."<<endl;
					cout<<endl;
				}
				
			}
		}
		
		if(menuChoice == 'u')
		{
			int playerSpot = 0;
			cout<<"Enter a jersey number:"<<endl;
			cin>>jerseyNumber;
			cout<<"Enter a new rating for player:"<<endl;
			cin>>rating;
			cout<<endl;
			for(int j = 0; j<10; j++)
			{
				if(playerJerseyNumber[j] == jerseyNumber)
				{
					playerSpot = j;
				}
			}
			playerRating[playerSpot] = rating;
		}
		
		if(menuChoice == 'r')
		{
			int counterToList = 1;
			int playerSpot = 0;
			cout<<"Enter a rating:"<<endl;
			cin>>rating;
			cout<<endl;
			cout<<"ABOVE "<<rating<<endl;
			for(int j=0; j<10; j++)
			{
				if(playerRating[j] > rating)
				{
					playerSpot = j;
					cout<<"Player "<<(j+1)<<" -- Jersey number: "<<playerJerseyNumber[playerSpot]<<", Rating: "<<playerRating[playerSpot]<<endl;
					counterToList++;
				}
			}
			cout<<endl;
			
		}
		
		if(menuChoice == 'o')
		{
		   cout<<"ROSTER"<<endl;
			int counterOutput = 1;
			for(int j =0; j<10; j++)
			{
				if(playerRating[j] != 0)
				{
					cout<<"Player "<<counterOutput<<" -- Jersey number: "<<playerJerseyNumber[j]<<", Rating: "<<playerRating[j]<<endl;
					counterOutput++;
				}
			}
			cout<<endl;
		}
		
		if(menuChoice == 's')
		{
			int playerSpot;
			int minJerseyNumber = 99999;
			cout<<"Executing secret option!"<<endl;
			cout<<endl;
			
			for(int i = 0; i<10; i++)
			{
				//cout<<"hello"<<endl;
				for(int j = 0; j<10; j++)
				{
					if( (playerJerseyNumber[j] < minJerseyNumber) && (playerJerseyNumber[j] != 0) )
					{
						minJerseyNumber = playerJerseyNumber[j];
						playerSpot = j;					
					}
									
				}
				newPlayerJerseyNumber[i] = playerJerseyNumber[playerSpot];
				newPlayerRating[i] = playerRating[playerSpot];
				
				playerJerseyNumber[playerSpot] = 0;
				playerRating[playerSpot] = 0;
				minJerseyNumber = 9999;
			}
			
			int counterToRoster = 1;
			for(int j =0; j<10; j++)
			{
				playerJerseyNumber[j] = newPlayerJerseyNumber[j];
				playerRating[j] = newPlayerRating[j];
			}
			
		}
			
			
			
	}
	
			
	}	