#include <iostream>
#include <string>
#include <iomanip>
#include <sstream>
#include <fstream>
using namespace std;
//Add libraries, namespace, structure and functions
struct course
   {
      string title;
      string code;
      int class_size;
      int enrolled;
      string roster[100];
   };
   
course getCourseFromFile(string name)
{
   course funcStructName;
   ifstream inFS;
   inFS.open(name.c_str());
   if(!inFS.is_open())
   {
      cout<<"Error! File not found."<<endl;
   }
   else
   {
   getline(inFS,funcStructName.title);
   inFS>>funcStructName.code;
   inFS>>funcStructName.class_size;
   
   string temp;
   getline(inFS, temp);
   
   int student_counter = 0;
   while (!inFS.eof())
   {
   	getline(inFS, funcStructName.roster[student_counter]);
   	student_counter = student_counter +1;
   }
   
    int student_count = 0;
	while(!funcStructName.roster[student_count].empty())
	{
		student_count++;
	}
	funcStructName.enrolled = student_count;
	//cout<<funcStructName.enrolled;
   
   inFS.close();
   }
   return funcStructName;
}

bool checkCourseSize(course input)
{
	int student_count = 0;
	while(!input.roster[student_count].empty())
	{
		student_count++;
	}
	//cout<<student_count<<endl;
	
	if(input.class_size >= student_count)
	{
		return true;
	}
	
	if(input.class_size != student_count)
	{
		return false;
	}
}

void printRoster(course input)
{
	int num_students = 0;
	while(!input.roster[num_students].empty())
	{
		//cout<<input.roster[num_students]<<endl;
		num_students++;
	}
	
	for(int i=0; i<num_students;i++)
	{
		cout<<input.roster[i]<<endl;
	}
	//cout<<input.roster[num_students-1];
}

void saveCourseSummary(string outputFileName, course input)
{
	ofstream outFS;
	outFS.open(outputFileName.c_str());   
	bool check = checkCourseSize(input);
	//cout<<check<<endl;
	
	if(check == 1)
	{
		outFS<<"Course title: "<<input.title<<endl<<"Course code: "<<input.code<<endl<<"Class size: "<<input.class_size<<endl<<"Students enrolled: "<<input.enrolled<<endl;
	}
	
	if(check == 0)
	{
		
		outFS<<"Course title: "<<input.title<<endl<<"Course code: "<<input.code<<endl<<"Class size: "<<input.class_size<<endl<<"Students enrolled: "<<input.enrolled<<endl<<"Enrollment exceeds class size. Drop students or find bigger classroom."<<endl;
		
	}
	
	outFS.close();
}


int main()
{
   //Uncomment when ready to test
   //DO NOT MODIFY
   
   string filename;
   cin >> filename;
   course mycourse = getCourseFromFile(filename);   
   printRoster(mycourse);
   saveCourseSummary("output.txt", mycourse);
      
   return 0;
}
