#include <iostream>
#include <iomanip>
#include <string>
#include <fstream>
#include <sstream>
#include "Team.h"
#include "myArrayList.h"

using namespace std;

class FileIOError
{
   public:
      
};

class InvalidOption
{
   public:
      
};

class invalidLine
{
   public:
      
};

int main()
{
    string filename;
    cin>>filename;
    ifstream inFS;

    try
    {
        inFS.open(filename);
        if(!inFS.is_open())
        {
        throw FileIOError();
        }
    }
    catch(FileIOError)
    {
        cout<<"Error: Could not open file."<<endl;
        return 0;
    }

    int optionChosen;

    try
    {
        cin>>optionChosen;
        if( (optionChosen!=1) && (optionChosen!=2) && (optionChosen!=3) )
        {
            throw InvalidOption();
        }
    }
    catch(InvalidOption)
    {
        cout<<"Error: Invalid option. Choose from options 1(read doubles file), 2(read string file), 3(read nfl team file)."<<endl;
        return 0;
    }
    
    if(optionChosen == 1)
    {
        int arrSize;
        inFS>>arrSize;     
        myArrayList<double> newList(arrSize);

        double temp;
        while(!inFS.eof())
        {
            inFS>>temp;
            newList.addElement(temp);
        }

        newList.sortArray();
        newList.Print();        
    }

    if(optionChosen == 2)
    {
        int arrSize;
        inFS>>arrSize;
        inFS.ignore();
        inFS.ignore();        
        myArrayList<string> newList(arrSize);

        string temp;
        while(!inFS.eof())
        {
            getline(inFS, temp);
            newList.addElement(temp);
        }

        newList.sortArray();
        newList.Print();        
    }

    if(optionChosen == 3)
    {
        int arrSize;
        string trash;
        
        inFS>>arrSize;
        getline(inFS, trash);
        myArrayList<Team> newList(arrSize);

        while(!inFS.eof())
        {
            string line;
            string tempName = "";
            string tempWins = "";
            int realWins;
            string tempTies = "";
            int realTies;
            string tempLosses = "";
            int realLosses;

            getline(inFS, line);
            stringstream inSS(line);
            inSS>>tempName>>tempWins>>tempTies>>tempLosses;
            //cout<<tempName<<" "<<tempWins<< " "<<tempTies<< " "<<tempLosses<<endl;
            try
            {
                realWins = stoi(tempWins);
                realTies = stoi(tempTies);
                realLosses = stoi(tempLosses);

                Team tempTeam(tempName, realWins, realTies, realLosses);
                newList.addElement(tempTeam);                
            }
            catch(std::invalid_argument &e)
            {
                cout<<"Invalid argument, expected string int int int, on line: " <<line<<endl;
                //cout<<tempName<<" "<<tempWins<< " "<<tempTies<< " "<<tempLosses<<endl;

            }                   
        }
        newList.sortArray();
        newList.Print();
    }

}