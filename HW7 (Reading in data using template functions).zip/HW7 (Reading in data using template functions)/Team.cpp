#include <iostream>
#include <iomanip>
#include <string>
#include <fstream>
#include "Team.h"
#include <sstream>
using namespace std;

string Team::getName() const
{
    return name;
}
int Team::getWins() const
{
    return wins;
}
int Team::getLosses() const
{
    return losses;
}
int Team::getTies() const
{
    return ties;
}

Team::Team()
{
    name = "";
    wins = 0;
    losses = 0;
    ties = 0;
}

Team::Team(string startName, int startWins, int startTies, int startLosses)
{
    name = startName;
    wins = startWins;
    ties = startTies;
    losses = startLosses;
}

bool Team::operator<(Team &teamToCompare)
{ 
    if( (wins == teamToCompare.getWins()) && (ties == teamToCompare.getTies()) && (losses == teamToCompare.getLosses()) )
    {
        return name<teamToCompare.getName();
    }

    if( (wins == teamToCompare.getWins()) && (ties == teamToCompare.getTies()) )
    {
        return losses<teamToCompare.getLosses();
    } 

    if( wins == teamToCompare.getWins() )
    {
         return ties>teamToCompare.getTies();
    }
         return wins>teamToCompare.getWins();     

}

bool Team::operator==(Team &otherTeam)
{
    if(this->name == otherTeam.getName())
    {
        return true;
    }

    return false;
}

std::ostream& operator << (std::ostream& os,const Team& t)
{
    os << t.getName() << " W:" << t.getWins() << " T:" << t.getTies() << " L:" << t.getLosses();
    return os;
}
