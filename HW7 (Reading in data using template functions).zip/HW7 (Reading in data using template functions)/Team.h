#ifndef TEAM_H
#define TEAM_H

#include <iostream>
#include <string>
using namespace std;

class Team
{
    private:
        string name;
        int wins;
        int losses;
        int ties;

    public:
        Team();
        Team(string startName, int startWins, int startTies, int startLosses);
        bool operator<(Team &teamToCompare);
        bool operator==(Team &otherTeam);
        string getName() const;
        int getWins() const;
        int getLosses() const;
        int getTies() const;

};

std::ostream& operator << (std::ostream& os, const Team& t);

#endif