#include <iostream>
#include <fstream>
#include <string>

using namespace std;

template<typename TheType>
class myArrayList
{
    private:
        int numElements;
        int size;
        TheType *arr;
    public:
        myArrayList();
        myArrayList(int sizeToSet);
        ~myArrayList();
        int getNumElements() const;
        int getSize() const;
        void addElement(TheType elementToAdd);
        void deleteElement(TheType elementToDelete);
        bool searchElement(TheType elementToSearch);
        void sortArray();
        void Print();
};

template<typename TheType>
myArrayList<TheType>::myArrayList()
{
    this->size = 10;
    this->numElements = 0;
    arr = new TheType[size];
}

template<typename TheType>
myArrayList<TheType>::myArrayList(int sizeToSet)
{
    this->size = sizeToSet;
    this->numElements = 0;
    arr = new TheType[size];
}

template<typename TheType>
myArrayList<TheType>::~myArrayList()
{
    delete[] arr;
    arr = nullptr;
}

template<typename TheType>
int myArrayList<TheType>::getNumElements() const
{
    return numElements;
}

template<typename TheType>
int myArrayList<TheType>::getSize() const
{
    return size;
}

template<typename TheType>
void myArrayList<TheType>::addElement(TheType elementToAdd)
{
    try
    {
        for(int i=0; i<numElements; i++)
        {
            if( (*(arr+i)) == elementToAdd)
            {
                throw runtime_error("Element exists already!");
            }
        }

        if(numElements >= size)
        {
            throw runtime_error("List already full!");
        }

        if(numElements < size)
        {
            *(arr + numElements) = elementToAdd;
            numElements++;
        }
    }
    catch (runtime_error &excpt) 
    {
        // Prints the error message passed by throw statement
        cout << excpt.what() << endl;
    }
}

template<typename TheType>
void myArrayList<TheType>::deleteElement(TheType elementToDelete)
{
    int indexOfDeleted;
    TheType tempForShift;
    {
        for (int i = 0; i < numElements; i++)
        {
            if (arr[i] == elementToDelete)
            {
                for (int j = i; j < numElements - 1; j++)
                {
                    swap(arr[j], arr[j+1]);
                }            
                arr[numElements - 1] = NULL;
                numElements--;
            }
        }
    }
}

template<typename TheType>
bool myArrayList<TheType>::searchElement(TheType elementToSearch)
{
    for(int i=0; i<numElements; i++)
    {
        if( *(arr+i) == elementToSearch )
        {
            return true;
        }
    }

    return false;
}

template<typename TheType>
void myArrayList<TheType>::sortArray()
{
    TheType temp;
    for(int i=0; i<numElements; i++)
    {
        for(int j=i+1; j<numElements; j++)
        {
            if(arr[j]<arr[i])
            {
                temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
    }
}

template<typename TheType>
void myArrayList<TheType>::Print()
{
    for(int i= 0; i<numElements; i++)
    {
        cout<<*(arr+i)<<endl;
    }
}
