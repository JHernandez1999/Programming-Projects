#include <iostream>
#include <iomanip>
#include <string>
#include <fstream>
#include "item.h"
#include "vendingMachine.h"
#include <sstream>
using namespace std;

VendingMachine::VendingMachine(Item arrOfItems[10], int arrOfQuantities[10])
{
	for(int i = 0; i<10; i++)
	{
		items[i].setName(arrOfItems[i].getName());
		items[i].setPrice(arrOfItems[i].getPrice());
	}
	
	for(int i = 0; i<10; i++)
	{
		quantities[i] = arrOfQuantities[i];
	}
	
	cash = 0;
	credit = 0;
	
	
}

float VendingMachine::insertDollar()
{
	credit++;	
	return credit;
}

float VendingMachine::insertQuarter()
{
	credit = credit + 0.25;

	return credit;
}

void VendingMachine::printMenu()
{
	int numbering = 1;
	for(int i=0; i<10; i++)
	{
		cout<<numbering<<") "<<items[i].toString()<<endl;
		numbering++;
	}
	cout<<endl;
}

void VendingMachine::selectItem()
{
	int itemNumber;
	cout<<"Enter item number:"<<endl;
	cin>>itemNumber;
	itemNumber--;
	
	if(quantities[itemNumber] == 0)
	{
		cout<<"Sorry! Item Not Available"<<endl<<endl;
	}
	
	if( (quantities[itemNumber]>0) && (quantities[itemNumber]<=10) )
	{
		if(items[itemNumber].getPrice()>credit)
		{
			cout<<"Insufficient credit"<<endl<<endl;
		}
		else
		{
			cash = cash + (items[itemNumber].getPrice());
			credit = credit - (items[itemNumber].getPrice());
			quantities[itemNumber] = (quantities[itemNumber]-1);
			cout<<"Enjoy your "<<items[itemNumber].getName()<<endl<<endl;			
		}
	}
	
}

float VendingMachine::cancel()
{
	float temp = credit;
	credit = 0;
	return temp;
}

void VendingMachine::printReportToFile()
{
	ofstream outFS;
	outFS.open("log.txt");
	outFS<<"Current cash in machine: $"<<fixed<<setprecision(2)<<cash<<endl;
	outFS<<"Items needed:"<<endl;
	for(int i =0; i<10; i++)
	{
		outFS<<items[i].getName()<<": "<<(10-quantities[i])<<endl;
	}
	outFS.close();
	
}

VendingMachine::VendingMachine()
{
}


