#include <iostream>
#include <iomanip>
#include <string>
#include <fstream>
#include "item.h"
#include "vendingMachine.h"
using namespace std;

int main()
{
	
	Item objects[10];
	int numbers[10];
	
	ifstream inFS;
	string fileName;
	getline(cin, fileName);
	inFS.open(fileName.c_str());
	
	string name;
	string price;
	string quantity;
	for(int i = 0; i<10; i++)
	{
		getline(inFS, name);
		objects[i].setName(name);
		getline(inFS, price);
		objects[i].setPrice(stof(price));
		getline(inFS, quantity);
		numbers[i] = (stoi(quantity));
	}
	
	VendingMachine vendingObject(objects, numbers);
	
	int selection = 9;
	
	while(selection != 5)
	{
		cout<<"Make a selection: "<<endl<<"1 - insert 1$ bill"<<endl<<"2 - insert a quarter"<<endl<<"3 - view menu"<<endl<<"4 - select an item"<<endl<<"5 - cancel"<<endl<<endl;
		cin>>selection;
		
		if(selection == 1)
		{
			float tempCredit;
			tempCredit = vendingObject.insertDollar();
			cout<<"Total credit: $"<<fixed<<setprecision(2)<<tempCredit<<endl<<endl;
		}
		
		if(selection == 2)
		{
			float tempCredit2;
			tempCredit2 = vendingObject.insertQuarter();
			cout<<"Total credit: $"<<fixed<<setprecision(2)<<tempCredit2<<endl<<endl;
		}
		
		if(selection == 3)
		{
			vendingObject.printMenu();
		}
		
		if(selection == 4)
		{
			vendingObject.selectItem();
		}		
		
	}
	
	if(selection == 5)
	{
		float change = vendingObject.cancel();
		if(change == 0)
		{
			cout<<"No change"<<endl<<endl;
		}
		else
		{
			cout<<"Your change is $"<<fixed<<setprecision(2)<<change<<endl<<endl;
		}
		vendingObject.printReportToFile();
	}
	
	
}

