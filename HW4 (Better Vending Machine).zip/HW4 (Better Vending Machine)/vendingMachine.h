#ifndef VENDING_MACHINE_H
#define VENDING_MACHINE_H
#include "item.h"
#include <iostream>
#include <iomanip>
#include <string>
#include <fstream>
using namespace std;


class VendingMachine
{
	public:
		VendingMachine(Item arrOfItems[10], int arrOfQuantities[10]);
		VendingMachine();
		float insertDollar();
		float insertQuarter();
		void printMenu();
		void selectItem();
		float cancel();
		void printReportToFile();
		
	private:
		float cash;
		float credit;	
		Item items[10];
		int quantities[10];
		
};

#endif
