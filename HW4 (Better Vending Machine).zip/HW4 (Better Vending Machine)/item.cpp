#include <iostream>
#include <iomanip>
#include <string>
#include <fstream>
#include "item.h"
#include <sstream>
using namespace std;

Item::Item()
{
	name = "";
	price = 0;
}

void Item::setName(string item_name)
{
	name = item_name;
}

void Item::setPrice(float amountt)
{
	price = amountt;
}

string Item::getName()
{
	return name;
}

float Item::getPrice()
{
	return price;
}

string Item::toString()
{
	string together;
	ostringstream outSS;
	outSS<<name<<": $"<<fixed<<setprecision(2)<<price;
	together = outSS.str();
	outSS.str("");
	
	return together;
	
}
