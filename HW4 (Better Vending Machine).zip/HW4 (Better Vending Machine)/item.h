#ifndef ITEM_H
#define ITEM_H

#include <iostream>
#include <iomanip>
#include <string>
#include <fstream>
using namespace std;


class Item
{
	public:
		Item();
		void setName(string itemName);
		void setPrice(float amount);
		string getName();
		float getPrice();	
		string toString();	
		
	private:
		string name;
		float price;	
		
		
};

#endif
