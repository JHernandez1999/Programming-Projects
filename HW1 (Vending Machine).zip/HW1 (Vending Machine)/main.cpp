
#include <iostream>
#include <math.h>
#include <iomanip>
using namespace std;

int main()
{
    cout << fixed << setprecision(2);
    
    double credit = 0.0;
    int item;
    char selection;
    
    cout<<"Make a selection: "<<endl<<"d - insert 1$ bill"<<endl<<"m - view menu"<<endl<<"s - select an item"<<endl<<"c - get change"<<endl;
    cin>>selection;
    cout<<endl;
    
    while(1)
    {
   
    if( (selection != 'd') && (selection != 'm') && (selection != 's') && (selection != 'c') )
    {
       cout<<"Invalid selection"<<endl;
       cout<<endl;
    }
    
    if( selection == 'c')
    {
       break;
    }
    
    if( selection == 'd')
    {
       credit ++;
       cout<<"Credit available: $"<<credit<<endl;
       cout<<endl;
    }
    
    if( selection == 'm' )
    {
       cout<<"Available items:";
       cout<<endl;
       cout<<"(1) KitKat: $2.30";
       cout<<endl;
       cout<<"(2) Coca-Cola: $1.50";
       cout<<endl;
       cout<<"(3) Bottle of water: $0.80";
       cout<<endl;
       cout<<endl;
    }
    
    if( selection == 's' )
    {
       cout<<"Insert item number: "<<endl;
       cin>>item;
       
       if(item == 1)
       {
          if(credit<2.30)
          {
             cout<<"Insufficient credit"<<endl;
             cout<<endl;
          }          
          if(credit>=2.30)
          {
             credit = credit-(2.30);
             cout<<"Enjoy your KitKat!"<<endl;
             cout<<endl;
          }
       }
       
       if(item == 2)
       {
        if(credit<1.50)
          {
             cout<<"Insufficient credit"<<endl;
             cout<<endl;
          }          
          if(credit>=1.50)
          {
             credit = credit-(1.50);
             cout<<"Enjoy your Coca-Cola!"<<endl;
             cout<<endl;
          }  
       }
       
       if(item == 3)
       {
          if(credit<0.80)
          {
             cout<<"Insufficient credit"<<endl;
             cout<<endl;
          }          
          if(credit>=0.80)
          {
             credit = credit-(0.80);
             cout<<"Enjoy your water!"<<endl;
             cout<<endl;
          }
       }
       
       if( (item!=1) && (item!=2) && (item!=3) )
       {
          cout<<"Invalid item number"<<endl;
          cout<<endl;
       }
       
    }    
    
    cout<<"Make a selection: "<<endl<<"d - insert 1$ bill"<<endl<<"m - view menu"<<endl<<"s - select an item"<<endl<<"c - get change"<<endl;
    cin>>selection;
    cout<<endl;
    
    }
    
    if(credit == 0)
    {
       cout<<"No change"<<endl<<"Goodbye!"<<endl;
       cout<<endl;
    }
    else
    {
       cout<<"Your change is: $"<<credit<<endl<<"Goodbye!"<<endl;
       cout<<endl;
    }
    
          
    
}
