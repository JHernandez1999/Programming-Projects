#ifndef PARTY_H
#define PARTY_H

#include <iostream>
#include <iomanip>
#include <string>
#include <fstream>
using namespace std;


class Party
{
	public:
        Party();
        Party(string newDate, string newLocation, string newOrganizer, int newMaxAttendees);
        Party(const Party& someParty);                                      //copy constructor 
        ~Party();                                                           //deconstructor 
        void addAttendee(string nameToAdd);                                 //mutator
        void deleteAttendee(string nameToDelete);                           //mutator

        int findAttendee(string nameToFind);                                //accessor
        string getDate();                                                   //accessor
        string getLocation();                                               //accessor
        string getOrganizer();                                              //accessor
        int getMaxAttendees();                                              //accessor 
        int getNumAttendees();                                              //accessor

        void setDate(string dateToSet);                                     //mutator
        void setLocation(string locationToSet);                             //mutator
        void setOrganizer(string organizerToSet);                           //mutator
        void print();

        Party& operator=(const Party& someParty);                           //overloaded assignment operator =
        Party operator+(Party someParty);                                   //overloading + operator



    private:
        string date;                                                        // use the format mm/dd/yyyy
        string location;
        string organizer;
        int maxAttendees;
        int numAttendees;
        string *attendees;                                                  // holds a list of attendees with 'maxAttendees' entries, out of which 'numAttendees' are filled

		
};

#endif
