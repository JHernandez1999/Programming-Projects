#include <iostream>
#include <iomanip>
#include <string>
#include <fstream>
#include "Party.h"
#include <sstream>
using namespace std;

//DEFAULT CONSTRUCTOR
Party::Party()
{
    date = "";
    location = "";
    organizer = "";
    maxAttendees = 30;
    numAttendees = 0;
    attendees = new string[maxAttendees];
}

//CONSTRUCTOR WITH PARAMETERS
Party::Party(string newDate, string newLocation, string newOrganizer, int newMaxAttendees)
{
    date = newDate;
    location = newLocation;
    organizer = newOrganizer;
    numAttendees = 0;

    if(newMaxAttendees < 0)
    {
        maxAttendees = 30;
    }
    else
    {
        maxAttendees = newMaxAttendees;
    }

    attendees = new string[maxAttendees];

}

void Party::addAttendee(string nameToAdd)
{
    int duplicateFlag;

    for(int i=0; i<numAttendees; i++)
    {
        if(nameToAdd == *(attendees+i) )
        {
            duplicateFlag = 1;
        }
    }

    if(duplicateFlag != 1)
    {
        if(numAttendees == maxAttendees)
        {
            cout<<"Your party is already full!"<<endl;
        }
        else
        {
            *(attendees + numAttendees) = nameToAdd;
            numAttendees++;
        }
    }
}

void Party::deleteAttendee(string nameToDelete)
{
   for (int i = 0; i < numAttendees; i++)
    {
        if (attendees[i] == nameToDelete) // Going through array until we find name
        {
            for (int j=i; j < numAttendees-1; j++)
            {
                attendees[j] = attendees[j+1];  // Once the match is found, from there we start to swap attendee indicies with their index plus one.
            }

            
            attendees[maxAttendees - 1] = ""; // Tried with AND without this. Neither worked.
            numAttendees--; // subtract from numAttendees
        }
        break;  // finally, break from loop because no duplicate names are allowed anyway
    }
}

int Party::findAttendee(string nameToFind)
{
    int duplicateFlag;

    for(int i=0; i<numAttendees; i++)
    {
        if(nameToFind == *(attendees+i) )
        {
            duplicateFlag = 1;
        }
    }

    return duplicateFlag;
}

//ACCESSOR FUNCTIONS
string Party::getDate()
{
    string dateToReturn = date;
    return date;
}

string Party::getLocation()
{
    string locationToReturn = location;
    return locationToReturn;
}

string Party::getOrganizer()
{
    string organizerToReturn = organizer;
    return organizerToReturn;
}

int Party::getMaxAttendees()
{
    int maxAttendeesToReturn = maxAttendees;
    return maxAttendeesToReturn;
}

int Party::getNumAttendees()
{
    int numAttendeesToReturn = numAttendees;
    return numAttendeesToReturn;
}

//MUTATOR FUNCTIONS
void Party::setDate(string dateToSet)
{
    date = dateToSet;
}

void Party::setLocation(string locationToSet)
{
    location = locationToSet;
}

void Party::setOrganizer(string oragnizerToSet)
{
    organizer = oragnizerToSet;
}


//PRINT FUNCTION
void Party::print()
{
    if(numAttendees == 0)
    {
        cout<<"Party details:"<<endl;
        cout<<"Date: "<<date<<endl;
        cout<<"Location: "<<location<<endl;
        cout<<"Organizer: "<<organizer<<endl;
        cout<<"List is empty! Invite more people to your party."<<endl;
    }
    else
    {
        cout<<"Party details:"<<endl;
        cout<<"Date: "<<date<<endl;
        cout<<"Location: "<<location<<endl;
        cout<<"Organizer: "<<organizer<<endl;
        cout<<"Attendees list:"<<endl;

        for(int i = 0; i<numAttendees; i++)
        {
            cout<<*(attendees + i)<<endl;
        }
    }
}

//DECONSTRUCTOR 
Party::~Party()
{
    delete[] attendees;
    attendees = nullptr;
}

//COPY CONSTRUCTOR 
Party::Party(const Party& someParty)
{
    date = someParty.date;
    location = someParty.location;
    organizer = someParty.organizer;
    maxAttendees = someParty.maxAttendees;
    numAttendees = someParty.numAttendees;

    attendees = new string[someParty.maxAttendees];
    for (int i = 0; i<numAttendees; i++)
    {
        this->attendees[i] = someParty.attendees[i];
    }
}

//OVERLOAD OPERATION
Party& Party::operator=(const Party& someParty)
{
    date = someParty.date;
    location = someParty.location;
    organizer = someParty.organizer;
    maxAttendees = someParty.maxAttendees;
    numAttendees = someParty.numAttendees;

    delete[] attendees;
    attendees = nullptr;

    attendees = new string[maxAttendees];
    for (int i = 0; i<numAttendees; i++)
    {
        attendees[i] = someParty.attendees[i];
    }

    return *this;
}
 
//OVERLOAD + OPERATOR
 Party Party::operator+(Party someParty)
{
    int combinedMax = maxAttendees + someParty.maxAttendees;
    Party combinedParty("", "", "", combinedMax);

    if(date == someParty.date)    
    {
        combinedParty.date = date;
    }

    if(location == someParty.location)
    {
        combinedParty.location = location;
    }

    if(organizer== someParty.organizer)
    {
        combinedParty.organizer = organizer;
    }

    for(int i =0; i<numAttendees; i++)
    {
        combinedParty.attendees[i] = attendees[i];
    }
    combinedParty.numAttendees = numAttendees + someParty.numAttendees;

    int newCounter =0;
    for(int i=numAttendees; i<combinedParty.numAttendees; i++)
    {
        combinedParty.attendees[i] = someParty.attendees[newCounter];
        newCounter++;
    }

    return combinedParty;
}


