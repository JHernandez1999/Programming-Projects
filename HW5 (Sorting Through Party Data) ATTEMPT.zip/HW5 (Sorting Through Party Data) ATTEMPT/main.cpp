#include <iostream>
#include <iomanip>
#include <string>
#include <fstream>
#include "Party.h"
using namespace std;

int main()
{
    string tempDate;
    string tempLocation;
    string tempOrganizer;
    string tempMaxAttendee;
    string tempAttendee;
    int realMaxAttendees;

    ifstream inFS;
    string filename;
    getline(cin, filename);
    inFS.open(filename);

    getline(inFS, tempDate);
    getline(inFS, tempLocation);
    getline(inFS, tempOrganizer);
    getline(inFS, tempMaxAttendee);
    realMaxAttendees = stoi(tempMaxAttendee);

    Party p1(tempDate, tempLocation, tempOrganizer, realMaxAttendees);
    while(!inFS.eof())
    {
        getline(inFS,tempAttendee);
        p1.addAttendee(tempAttendee);
    }

    p1.print();
    inFS.close();
    return 0;
    
    //testing starts here

    /* TESTING DELETE ATTENDEE FUNCTION
    string name;
    getline(cin, name);
    p1.deleteAttendee(name);
    p1.print();
    */

    /* TESTING OPERATORS
    getline(cin, filename);
    inFS.open(filename);

    getline(inFS, tempDate);
    getline(inFS, tempLocation);
    getline(inFS, tempOrganizer);
    getline(inFS, tempMaxAttendee);
    realMaxAttendees = stoi(tempMaxAttendee);

    Party p2(tempDate, tempLocation, tempOrganizer, realMaxAttendees);
    while(!inFS.eof())
    {
        getline(inFS,tempAttendee);
        p2.addAttendee(tempAttendee);
    }

    p2.print();

    cout<<endl<<endl;
    Party p3;
    p3 = p1 + p2;
    p3.print();
    */
    
}
